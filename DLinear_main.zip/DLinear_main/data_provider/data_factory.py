from data_provider.data_loader import Dataset_ETT_hour, Dataset_ETT_minute, Dataset_Custom, Dataset_Pred
from torch.utils.data import DataLoader
import torch

data_dict = {
    'ETTh1': Dataset_ETT_hour,
    'ETTh2': Dataset_ETT_hour,
    'ETTm1': Dataset_ETT_minute,
    'ETTm2': Dataset_ETT_minute,
    'custom': Dataset_Custom,
}

# 定义 collate_fn 函数
def my_collate_fn(batch):
    # 拼接每个样本的张量
    tensor0 = [item for item in batch]
    final_tensor0 = torch.cat(tensor0, dim=0)
    # tensor1 = [item for item in batch[1]]
    # final_tensor1 = torch.cat(tensor1, dim=0)
    # tensor2 = [item for item in batch[2]]
    # final_tensor2 = torch.cat(tensor2, dim=0)
    # tensor3 = [item for item in batch[3]]
    # final_tensor3 = torch.cat(tensor3, dim=0)
    # return final_tensor0, final_tensor1, final_tensor2, final_tensor3
    return final_tensor0, final_tensor0, final_tensor0, final_tensor0

# 创建示例数据集和数据加载器
# dataset = MyDataset(range(10))
# dataloader = DataLoader(dataset, batch_size=2, collate_fn=my_collate_fn)

def data_provider(args, flag):
    Data = data_dict[args.data]
    timeenc = 0 if args.embed != 'timeF' else 1
    train_only = args.train_only

    if flag == 'test':
        shuffle_flag = False
        drop_last = False
        batch_size = args.batch_size
        freq = args.freq
    elif flag == 'pred':
        shuffle_flag = False
        drop_last = False
        batch_size = 1
        freq = args.freq
        Data = Dataset_Pred
    else:
        shuffle_flag = True
        drop_last = True
        batch_size = args.batch_size
        freq = args.freq

    data_set = Data(
        root_path=args.root_path,
        data_path=args.data_path,
        flag=flag,
        size=[args.seq_len, args.label_len, args.pred_len],
        features=args.features,
        target=args.target,
        timeenc=timeenc,
        freq=freq,
        train_only=train_only
    )
    print(flag, len(data_set))
    data_loader = DataLoader(
        data_set,
        batch_size=batch_size,
        shuffle=shuffle_flag,
        num_workers=args.num_workers,
        drop_last=drop_last,
        collate_fn=my_collate_fn)
    return data_set, data_loader
